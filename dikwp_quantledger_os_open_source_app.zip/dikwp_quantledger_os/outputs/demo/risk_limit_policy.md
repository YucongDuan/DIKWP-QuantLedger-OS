# Quant Risk Limit Policy Template

## Scope
Research and paper-trading governance only. Live trading requires separate legal, compliance, broker and exchange approval.

## Minimum controls
- Position limit by strategy and instrument.
- Daily loss limit and drawdown freeze threshold.
- Order-rate and cancel-ratio cap.
- Pre-trade validation for price bands, notional, leverage and restricted instruments.
- Human review for C3+ actions.
- Kill switch with independent operator access.
- Post-trade reconciliation and audit hash chain.

## Prohibited patterns
Spoofing, layering, quote stuffing, wash trading, marking the close, self-trading or any reporting evasion.
