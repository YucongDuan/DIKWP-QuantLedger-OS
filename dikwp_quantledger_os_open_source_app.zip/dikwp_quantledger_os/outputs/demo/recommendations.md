# QuantLedger Recommendations

## cn-mf-001 — China A-share low-turnover multi-factor research strategy
Decision: **allow_research_only**. Risk score: **0.0**.

Reasons:
- No material issues detected within offline heuristic scope.

## cn-hft-002 — Latency-sensitive intraday microstructure scalper draft
Decision: **block**. Risk score: **1.0**.

Reasons:
- Data source order_book_ticks lacks provider.
- Data source order_book_ticks lacks adjustment policy.
- Data source order_book_ticks lacks survivorship bias check.
- Data source order_book_ticks has unclear data rights.
- No walk-forward validation declared.
- No out-of-sample validation declared.
- Transaction cost model missing.
- Slippage model missing.
- High parameter count with low trade count suggests overfitting risk.
- Unusually high return with very low drawdown; requires leakage/overfit review.
- Signal future_price_predictor contains possible look-ahead leakage terms.
- Program trading reporting readiness not declared.
- Auditability is not complete/strong.
- No explicit no-manipulation policy declared.
- Kill switch missing.
- Human review not required for high-control action.
- High-frequency style risk requires enhanced reporting and exchange/broker controls.
- Manipulative trading terminology detected.
- Live trading flag present; this tool requires governance review before any live use.
