# Program Trading Reporting Readiness Checklist

This checklist is a governance aid, not legal advice.

- [ ] Strategy owner and beneficial owner identified.
- [ ] Strategy type, asset class, market, instrument universe documented.
- [ ] Order generation logic summarized without exposing proprietary alpha.
- [ ] Order rate, cancel ratio, message rate and high-frequency indicators declared.
- [ ] Technical system tested before any production connection.
- [ ] Broker/exchange reporting obligations reviewed.
- [ ] Kill switch, risk limits, position limits and emergency contact declared.
- [ ] Data lineage and backtest reproducibility reviewed.
- [ ] Model/Agent card approved.
- [ ] Human compliance approval recorded.
