# Kill / Recovery Matrix

| Trigger | Kill Action | Recovery |
|---|---|---|
| Data leakage confirmed | Freeze strategy | Rebuild features and rerun OOS validation |
| Backtest cannot reproduce | Freeze strategy | Rebuild data lineage ledger |
| Reporting readiness missing | Block live mode | Complete compliance checklist |
| HFT risk above threshold | Human compliance review | Broker/exchange controls and throttles |
| Kill switch unavailable | Block C3+ actions | Implement independent kill switch |
| Manipulative terminology or order pattern | Block | Legal/compliance review |
| Live trading flag enabled in research package | Block | Separate regulated production approval |
