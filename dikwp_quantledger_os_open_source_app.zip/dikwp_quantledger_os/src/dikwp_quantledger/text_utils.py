import re
from typing import Iterable

LOOKAHEAD_TERMS = ["future", "next_day", "tomorrow", "forward_return", "label_leak", "post_trade", "future_price"]
MANIPULATION_TERMS = ["spoof", "layering", "quote stuffing", "mark close", "wash trade", "pump", "dump"]
GUARANTEE_TERMS = ["guarantee", "guaranteed", "risk-free", "100% profit", "sure win", "稳赚", "保本", "无风险"]


def contains_any(text: str, terms: Iterable[str]) -> bool:
    low = (text or "").lower()
    return any(t.lower() in low for t in terms)


def clamp(x: float, lo: float=0.0, hi: float=1.0) -> float:
    return max(lo, min(hi, x))


def normalize_words(text: str):
    return re.findall(r"[A-Za-z0-9_\u4e00-\u9fff]+", text or "")
