# Report helpers are currently generated inside analyzer.py for a minimal offline prototype.
