from pathlib import Path
import json

FORBIDDEN = [
    'import socket', 'import requests', 'import urllib', 'import httpx',
    'subprocess', 'os.system', 'eval(', 'exec(',
    'ccxt', 'ib_insync', 'ctp', 'xtquant', 'vnpy', 'easytrader', 'akshare', 'tushare',
    'place_order', 'send_order', 'cancel_order', 'broker_api', 'exchange_api'
]


def audit_path(path: str) -> dict:
    root=Path(path)
    findings=[]
    for p in root.rglob('*.py'):
        if p.name == 'static_audit.py':
            continue
        text=p.read_text(encoding='utf-8', errors='ignore')
        for term in FORBIDDEN:
            if term in text:
                findings.append({'file':str(p), 'term':term})
    return {
        'pass': len(findings)==0,
        'finding_count': len(findings),
        'findings': findings,
        'policy': 'No network imports, subprocess, dynamic execution, live broker/data APIs, or order placement helpers in the offline core.'
    }
