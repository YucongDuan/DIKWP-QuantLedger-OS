from .models import DIKWPRecord


def strategy_to_dikwp(strategy: dict) -> DIKWPRecord:
    intent = strategy.get("intent_contract", {})
    data_sources = strategy.get("data_sources", [])
    signals = strategy.get("signals", [])
    backtest = strategy.get("backtest", {})
    risk = strategy.get("risk_controls", {})
    order = strategy.get("order_profile", {})
    compliance = strategy.get("compliance", {})
    sid = strategy.get("strategy_id", "unknown")
    return DIKWPRecord(
        object_id=sid,
        object_type="quant_strategy",
        D={
            "strategy_name": strategy.get("name"),
            "asset_class": strategy.get("asset_class"),
            "markets": strategy.get("markets", []),
            "data_sources": data_sources,
            "signals": [s.get("name") for s in signals],
            "backtest_period": backtest.get("period"),
        },
        I={
            "signal_to_order_path": strategy.get("signal_to_order_path", "not_declared"),
            "data_frequency": [d.get("frequency") for d in data_sources],
            "order_rate_per_minute": order.get("order_rate_per_minute"),
            "cancel_ratio": order.get("cancel_ratio"),
        },
        K={
            "model_family": strategy.get("model_family"),
            "risk_model": risk.get("risk_model"),
            "validation_methods": backtest.get("validation_methods", []),
            "known_failure_modes": strategy.get("known_failure_modes", []),
        },
        W={
            "market_fairness_boundary": compliance.get("market_fairness_boundary", "not_declared"),
            "retail_investor_impact_boundary": compliance.get("retail_investor_impact_boundary", "not_declared"),
            "no_manipulation_policy": compliance.get("no_manipulation_policy", False),
            "risk_limit_policy": risk,
        },
        P={
            "goal": intent.get("goal", ""),
            "value": intent.get("value", ""),
            "constraints": intent.get("constraints", []),
            "time_window": intent.get("time_window", ""),
            "feedback_plan": intent.get("feedback_plan", ""),
        },
        R={
            "evidence_level": strategy.get("evidence_level", "prototype"),
            "live_trading_enabled": strategy.get("live_trading_enabled", False),
            "reporting_readiness": compliance.get("program_trading_report_ready", False),
            "auditability": compliance.get("auditability", "partial"),
            "residuals": strategy.get("residuals", []),
        }
    )
