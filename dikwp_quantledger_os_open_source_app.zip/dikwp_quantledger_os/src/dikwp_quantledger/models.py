from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class IntentContract:
    goal: str = ""
    value: str = ""
    constraints: List[str] = field(default_factory=list)
    time_window: str = ""
    feedback_plan: str = ""

    def completeness(self) -> float:
        items = [self.goal, self.value, self.constraints, self.time_window, self.feedback_plan]
        return sum(1 for x in items if bool(x)) / len(items)

@dataclass
class StrategyDecision:
    strategy_id: str
    name: str
    decision: str
    risk_score: float
    compliance_score: float
    backtest_integrity_score: float
    purpose_alignment_score: float
    hft_risk_score: float
    reasons: List[str]
    kill_conditions: List[str]
    recovery_actions: List[str]

@dataclass
class DIKWPRecord:
    object_id: str
    object_type: str
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]
