import argparse, json
from pathlib import Path
from .analyzer import analyze_file
from .static_audit import audit_path


def main():
    parser=argparse.ArgumentParser(prog='quantledger')
    sub=parser.add_subparsers(dest='cmd', required=True)
    a=sub.add_parser('analyze')
    a.add_argument('input')
    a.add_argument('--out', default='outputs/demo')
    s=sub.add_parser('static-audit')
    s.add_argument('path')
    s.add_argument('--out', default='outputs/demo/static_boundary_audit_report.json')
    args=parser.parse_args()
    if args.cmd=='analyze':
        summary=analyze_file(args.input, args.out)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    elif args.cmd=='static-audit':
        result=audit_path(args.path)
        out=Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
