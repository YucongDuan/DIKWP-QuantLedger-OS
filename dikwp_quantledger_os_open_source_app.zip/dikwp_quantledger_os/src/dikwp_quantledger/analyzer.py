import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Tuple
from .models import IntentContract, StrategyDecision
from .dikwp import strategy_to_dikwp
from .text_utils import contains_any, clamp, LOOKAHEAD_TERMS, MANIPULATION_TERMS, GUARANTEE_TERMS


def score_intent(intent: dict) -> float:
    ic = IntentContract(
        goal=intent.get("goal", ""),
        value=intent.get("value", ""),
        constraints=intent.get("constraints", []),
        time_window=intent.get("time_window", ""),
        feedback_plan=intent.get("feedback_plan", ""),
    )
    return ic.completeness()


def score_data_lineage(strategy: dict) -> Tuple[float, List[str]]:
    reasons=[]
    sources=strategy.get('data_sources', [])
    if not sources:
        return 0.0, ['No data sources declared.']
    score=1.0
    for src in sources:
        if not src.get('provider'):
            score-=0.15; reasons.append(f"Data source {src.get('name','unknown')} lacks provider.")
        if not src.get('adjustment_policy'):
            score-=0.15; reasons.append(f"Data source {src.get('name','unknown')} lacks adjustment policy.")
        if src.get('survivorship_bias_checked') is False:
            score-=0.2; reasons.append(f"Data source {src.get('name','unknown')} lacks survivorship bias check.")
        if src.get('data_rights') not in ['licensed','internal','public']:
            score-=0.15; reasons.append(f"Data source {src.get('name','unknown')} has unclear data rights.")
    return clamp(score), reasons


def score_backtest(strategy: dict) -> Tuple[float, List[str], List[dict]]:
    reasons=[]; rows=[]
    backtest=strategy.get('backtest', {})
    score=1.0
    if not backtest.get('period'):
        score-=0.2; reasons.append('Backtest period missing.')
    if 'walk_forward' not in backtest.get('validation_methods', []):
        score-=0.18; reasons.append('No walk-forward validation declared.')
    if 'out_of_sample' not in backtest.get('validation_methods', []):
        score-=0.18; reasons.append('No out-of-sample validation declared.')
    if backtest.get('transaction_cost_model') in [None, '', 'none']:
        score-=0.15; reasons.append('Transaction cost model missing.')
    if backtest.get('slippage_model') in [None, '', 'none']:
        score-=0.15; reasons.append('Slippage model missing.')
    if backtest.get('parameter_count', 0) > 20 and backtest.get('trade_count', 0) < 1000:
        score-=0.18; reasons.append('High parameter count with low trade count suggests overfitting risk.')
    if backtest.get('annualized_return', 0) > 0.5 and backtest.get('max_drawdown', 1) < 0.03:
        score-=0.20; reasons.append('Unusually high return with very low drawdown; requires leakage/overfit review.')
    for signal in strategy.get('signals', []):
        text=' '.join([signal.get('name',''), signal.get('description',''), ' '.join(signal.get('features', []))])
        leak=contains_any(text, LOOKAHEAD_TERMS)
        rows.append({'strategy_id':strategy.get('strategy_id'), 'signal': signal.get('name'), 'lookahead_risk': leak, 'features': ';'.join(signal.get('features', []))})
        if leak:
            score-=0.3; reasons.append(f"Signal {signal.get('name')} contains possible look-ahead leakage terms.")
    return clamp(score), reasons, rows


def score_compliance(strategy: dict) -> Tuple[float, List[str], float]:
    reasons=[]
    comp=strategy.get('compliance', {})
    order=strategy.get('order_profile', {})
    score=1.0
    if not comp.get('program_trading_report_ready'):
        score-=0.22; reasons.append('Program trading reporting readiness not declared.')
    if comp.get('auditability') not in ['complete','strong']:
        score-=0.18; reasons.append('Auditability is not complete/strong.')
    if not comp.get('no_manipulation_policy'):
        score-=0.15; reasons.append('No explicit no-manipulation policy declared.')
    risk_controls = strategy.get('risk_controls', {})
    if not risk_controls.get('kill_switch'):
        score-=0.2; reasons.append('Kill switch missing.')
    if not risk_controls.get('human_review_required') and order.get('control_level', 'C0') in ['C3','C4','C5','C6','C7']:
        score-=0.15; reasons.append('Human review not required for high-control action.')
    hft=0.0
    order_rate=float(order.get('order_rate_per_minute') or 0)
    cancel=float(order.get('cancel_ratio') or 0)
    if order_rate>60: hft += 0.35
    if order_rate>300: hft += 0.35
    if cancel>0.5: hft += 0.25
    if order.get('co_location') or order.get('latency_sensitive'): hft += 0.25
    hft=clamp(hft)
    if hft>0.6:
        score-=0.2; reasons.append('High-frequency style risk requires enhanced reporting and exchange/broker controls.')
    risk_text=' '.join([str(x.get('description','')) + ' ' + str(x.get('name','')) for x in strategy.get('signals', [])] + strategy.get('known_failure_modes', []))
    marketing_text=strategy.get('marketing_claims','')
    if contains_any(risk_text, MANIPULATION_TERMS):
        score-=0.4; reasons.append('Manipulative trading terminology detected.')
    if contains_any(marketing_text, GUARANTEE_TERMS):
        score-=0.25; reasons.append('Guaranteed-profit language detected.')
    return clamp(score), reasons, hft


def decide(strategy: dict) -> StrategyDecision:
    purpose=score_intent(strategy.get('intent_contract', {}))
    data_score, data_reasons=score_data_lineage(strategy)
    backtest_score, backtest_reasons, _=score_backtest(strategy)
    comp_score, comp_reasons, hft=score_compliance(strategy)
    reasons=data_reasons+backtest_reasons+comp_reasons
    risk=clamp(1 - (0.25*purpose + 0.25*data_score + 0.25*backtest_score + 0.25*comp_score) + 0.15*hft)
    if strategy.get('live_trading_enabled'):
        risk=clamp(risk+0.15); reasons.append('Live trading flag present; this tool requires governance review before any live use.')
    if comp_score < 0.45 or backtest_score < 0.35 or hft > 0.75 or any('Manipulative' in r for r in reasons):
        decision='block'
    elif risk > 0.45 or purpose < 0.8 or comp_score < 0.75:
        decision='review'
    else:
        decision='allow_research_only'
    kill=[
        'look-ahead leakage confirmed',
        'unreported program-trading activity detected',
        'kill switch unavailable or disabled',
        'manipulative order pattern detected',
        'live deployment attempted without human approval and broker/exchange compliance',
        'backtest cannot be reproduced from declared data lineage'
    ]
    recovery=[
        'freeze strategy to research-only mode',
        'rerun data lineage and leakage audit',
        'complete program-trading reporting checklist',
        'enable human review and kill switch',
        'run paper-trading sandbox with full audit ledger',
        'obtain legal/compliance review before any live deployment'
    ]
    return StrategyDecision(
        strategy_id=strategy.get('strategy_id','unknown'),
        name=strategy.get('name','unknown'),
        decision=decision,
        risk_score=round(risk,4),
        compliance_score=round(comp_score,4),
        backtest_integrity_score=round(backtest_score,4),
        purpose_alignment_score=round(purpose,4),
        hft_risk_score=round(hft,4),
        reasons=reasons or ['No material issues detected within offline heuristic scope.'],
        kill_conditions=kill,
        recovery_actions=recovery
    )


def analyze_file(input_path: str, out_dir: str) -> dict:
    p=Path(input_path)
    data=json.loads(p.read_text(encoding='utf-8'))
    out=Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    strategies=data.get('strategies', [])
    decisions=[decide(s) for s in strategies]
    ledgers=[strategy_to_dikwp(s) for s in strategies]
    backtest_rows=[]
    data_rows=[]
    for s in strategies:
        _,_,rows=score_backtest(s); backtest_rows.extend(rows)
        for ds in s.get('data_sources', []):
            data_rows.append({'strategy_id':s.get('strategy_id'), **ds})
    summary={
        'system':'DIKWP QuantLedger OS',
        'version':'0.1.0',
        'portfolio_id': data.get('portfolio_id','unknown'),
        'strategy_count': len(strategies),
        'decision_summary': {k: sum(1 for d in decisions if d.decision==k) for k in sorted(set(d.decision for d in decisions))},
        'mean_risk_score': round(sum(d.risk_score for d in decisions)/len(decisions),4) if decisions else 0,
        'max_hft_risk_score': max((d.hft_risk_score for d in decisions), default=0),
        'action_boundary':'Research, audit, paper-trading governance, compliance readiness only; no live trading or investment advice.',
        'strategies':[asdict(d) for d in decisions]
    }
    (out/'quantledger_report.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'dikwp_strategy_ledger.json').write_text(json.dumps([asdict(x) for x in ledgers], ensure_ascii=False, indent=2), encoding='utf-8')
    # decision matrix
    with (out/'strategy_decision_matrix.csv').open('w', newline='', encoding='utf-8') as f:
        writer=csv.DictWriter(f, fieldnames=['strategy_id','name','decision','risk_score','compliance_score','backtest_integrity_score','purpose_alignment_score','hft_risk_score'])
        writer.writeheader()
        for d in decisions:
            row=asdict(d); row.pop('reasons'); row.pop('kill_conditions'); row.pop('recovery_actions'); writer.writerow(row)
    with (out/'backtest_integrity_matrix.csv').open('w', newline='', encoding='utf-8') as f:
        fields=['strategy_id','signal','lookahead_risk','features']; writer=csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(backtest_rows)
    with (out/'data_lineage_ledger.json').open('w', encoding='utf-8') as f:
        f.write(json.dumps(data_rows, ensure_ascii=False, indent=2))
    # model agent cards
    cards=[]
    for s in strategies:
        cards.append({
            'strategy_id':s.get('strategy_id'),
            'model_family':s.get('model_family'),
            'provider':'internal/research',
            'allowed_use':'research governance and paper-trading audit only',
            'prohibited_use':['live trading without compliance approval','market manipulation','personalized investment advice','reporting evasion'],
            'max_control_level':'C2 research advisory by default',
            'content_marking_policy':'Outputs must be marked as AI-assisted research artifacts when externally shared.'
        })
    (out/'model_agent_cards.json').write_text(json.dumps(cards, ensure_ascii=False, indent=2), encoding='utf-8')
    # Markdown reports
    checklist = """# Program Trading Reporting Readiness Checklist\n\nThis checklist is a governance aid, not legal advice.\n\n- [ ] Strategy owner and beneficial owner identified.\n- [ ] Strategy type, asset class, market, instrument universe documented.\n- [ ] Order generation logic summarized without exposing proprietary alpha.\n- [ ] Order rate, cancel ratio, message rate and high-frequency indicators declared.\n- [ ] Technical system tested before any production connection.\n- [ ] Broker/exchange reporting obligations reviewed.\n- [ ] Kill switch, risk limits, position limits and emergency contact declared.\n- [ ] Data lineage and backtest reproducibility reviewed.\n- [ ] Model/Agent card approved.\n- [ ] Human compliance approval recorded.\n"""
    (out/'program_trading_reporting_checklist.md').write_text(checklist, encoding='utf-8')
    risk_policy = """# Quant Risk Limit Policy Template\n\n## Scope\nResearch and paper-trading governance only. Live trading requires separate legal, compliance, broker and exchange approval.\n\n## Minimum controls\n- Position limit by strategy and instrument.\n- Daily loss limit and drawdown freeze threshold.\n- Order-rate and cancel-ratio cap.\n- Pre-trade validation for price bands, notional, leverage and restricted instruments.\n- Human review for C3+ actions.\n- Kill switch with independent operator access.\n- Post-trade reconciliation and audit hash chain.\n\n## Prohibited patterns\nSpoofing, layering, quote stuffing, wash trading, marking the close, self-trading or any reporting evasion.\n"""
    (out/'risk_limit_policy.md').write_text(risk_policy, encoding='utf-8')
    kr = """# Kill / Recovery Matrix\n\n| Trigger | Kill Action | Recovery |\n|---|---|---|\n| Data leakage confirmed | Freeze strategy | Rebuild features and rerun OOS validation |\n| Backtest cannot reproduce | Freeze strategy | Rebuild data lineage ledger |\n| Reporting readiness missing | Block live mode | Complete compliance checklist |\n| HFT risk above threshold | Human compliance review | Broker/exchange controls and throttles |\n| Kill switch unavailable | Block C3+ actions | Implement independent kill switch |\n| Manipulative terminology or order pattern | Block | Legal/compliance review |\n| Live trading flag enabled in research package | Block | Separate regulated production approval |\n"""
    (out/'kill_recovery_matrix.md').write_text(kr, encoding='utf-8')
    recs=[]
    for d in decisions:
        recs.append(f"## {d.strategy_id} — {d.name}\nDecision: **{d.decision}**. Risk score: **{d.risk_score}**.\n\nReasons:\n" + '\n'.join(f"- {r}" for r in d.reasons) + "\n")
    (out/'recommendations.md').write_text('# QuantLedger Recommendations\n\n'+'\n'.join(recs), encoding='utf-8')
    return summary
