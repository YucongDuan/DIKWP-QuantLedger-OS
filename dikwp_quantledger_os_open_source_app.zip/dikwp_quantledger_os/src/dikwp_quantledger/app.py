try:
    import streamlit as st
except Exception:  # optional dependency
    st = None

if st:
    st.title('DIKWP QuantLedger OS')
    st.write('Offline quant strategy semantic risk ledger. Upload a JSON manifest and run local analysis via CLI for full outputs.')
else:
    print('Install with pip install -e .[app] to run the optional Streamlit interface.')
