# Roadmap

- v0.2: Add richer backtest leakage checks.
- v0.3: Add strategy registry and TrustPassport metadata.
- v0.4: Add Chinese program-trading report template packs.
- v0.5: Add paper-trading audit replay bundle.
- v1.0: Certified enterprise version with human compliance workflow.
