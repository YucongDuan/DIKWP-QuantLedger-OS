# GitHub Release Draft

DIKWP QuantLedger OS v0.1.0 is released as an offline-first semantic risk ledger for quantitative trading research and program-trading governance. It generates DIKWP strategy ledgers, backtest integrity matrices, program-trading reporting checklists, risk limit policies, and kill/recovery matrices.

This release contains no live trading or broker connectivity.
