# Governance Boundary

QuantLedger OS is not investment advice, not a strategy recommendation engine, and not a live trading system.

It may be used for:

- strategy governance;
- data lineage review;
- backtest integrity review;
- program-trading readiness preparation;
- paper-trading audit;
- research-team discipline;
- compliance conversation prep.

It must not be used for:

- live trading;
- regulatory evasion;
- market manipulation;
- broker/exchange control bypass;
- guaranteed profit claims;
- personal investment advice.
