# Open Source Launch Plan

1. Publish repository with README, NOTICE, CITATION.cff, and MIT license.
2. Position as "quant governance and backtest integrity ledger", not alpha code.
3. Publish demo report screenshots and CLI examples.
4. Invite quant researchers, compliance officers, brokers, and university labs.
5. Offer official certification and paid regulatory-readiness templates separately.
