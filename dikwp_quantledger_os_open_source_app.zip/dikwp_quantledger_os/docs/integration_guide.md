# Integration Guide

The offline core can be integrated with:

- internal research notebooks;
- model-risk management systems;
- compliance approval workflows;
- paper-trading logs;
- ProofLedger for claim-to-evidence checks;
- AgentTrace for AI agent run logs;
- TrustPassport for official DIKWP project registration.

Live broker integration is intentionally out of scope for the open core.
