# Architecture

```text
Strategy Manifest
  -> DIKWP Registration
  -> Data Lineage Audit
  -> Backtest Integrity Gate
  -> Program Trading Readiness Gate
  -> HFT / Order-Rate Risk Gate
  -> Kill / Recovery Gate
  -> QuantLedger Report
```

The offline core deliberately has no broker APIs, no market-data APIs, no order placement helpers, and no network imports.
