from dikwp_quantledger.analyzer import analyze_file
from dikwp_quantledger.static_audit import audit_path
from pathlib import Path


def test_analyze_demo(tmp_path):
    summary = analyze_file('examples/sample_quant_strategy_portfolio.json', str(tmp_path))
    assert summary['strategy_count'] == 2
    assert summary['decision_summary']['block'] >= 1
    assert (tmp_path/'quantledger_report.json').exists()


def test_static_audit():
    result = audit_path('src')
    assert result['pass'] is True


def test_outputs_include_core_files(tmp_path):
    analyze_file('examples/sample_quant_strategy_portfolio.json', str(tmp_path))
    assert (tmp_path/'program_trading_reporting_checklist.md').exists()
    assert (tmp_path/'kill_recovery_matrix.md').exists()
