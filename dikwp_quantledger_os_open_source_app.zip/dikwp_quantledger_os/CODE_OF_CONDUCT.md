Be respectful. Do not contribute code that places live orders, bypasses reporting, or manipulates markets.
