Contributions should preserve auditability, no-live-trading boundaries, and DIKWP attribution.
