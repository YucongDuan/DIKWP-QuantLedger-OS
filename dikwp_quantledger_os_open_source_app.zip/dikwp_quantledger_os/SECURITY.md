Report security issues privately. The offline core must not include live broker APIs, network calls, subprocess execution, or hidden telemetry.
